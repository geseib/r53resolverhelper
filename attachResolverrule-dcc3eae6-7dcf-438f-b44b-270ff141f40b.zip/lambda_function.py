import json
import sys
import time
import os
import os.path

envLambdaTaskRoot = os.environ["LAMBDA_TASK_ROOT"]
print("LAMBDA_TASK_ROOT env var:"+os.environ["LAMBDA_TASK_ROOT"])
print("sys.path:"+str(sys.path))
 
sys.path.insert(0,envLambdaTaskRoot+"/attachResolverrule")
print("sys.path:"+str(sys.path))
 
import boto3

client = boto3.client('route53resolver')

def lambda_handler(event, context):
    print("boto3 version:"+boto3.__version__)
    print (event['vpc_id'])
    vpc_id = event['vpc_id']
    rule_id = event['rule_id']
    rule_name = event['rule_name']
    response = client.associate_resolver_rule(
    ResolverRuleId=rule_id,
    Name=rule_name,
    VPCId=vpc_id
    )
    print(response)